package com.j2cg.train;

import com.j2cg.base.CTCoolGenCore;

public class CYY1S011_TRAIN002 extends CTCoolGenCore {

	protected imp_error_iyy1_component m_LocalEntity001;
	protected iyy1_component m_LocalEntity002;
	
	@Override
	public void initialize(Object... inputs) {
	}
	
	@Override
	public void execute(Object...outputs) {
		m_LocalEntity001.dialect_cd = m_LocalEntity002.dialect_cd;
	}
}