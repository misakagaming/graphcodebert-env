package com.j2cg.train;

import com.j2cg.base.CTCoolGenCore;

public class CYY1S011_TRAIN002 extends CTCoolGenCore {

	protected group_context m_LocalEntity001;
	
	@Override
	public void initialize(Object... inputs) {
	}
	
	@Override
	public void execute(Object...outputs) {
		m_LocalEntity001.setSubscript(1);
	}
}