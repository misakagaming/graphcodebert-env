package com.j2cg.train;

import com.j2cg.base.CTCoolGenCore;

public class CYY1S011_TRAIN002 extends CTCoolGenCore {

	protected dont_change_return_codes m_LocalEntity001;
	
	@Override
	public void initialize(Object... inputs) {
	}
	
	@Override
	public void execute(Object...outputs) {
		m_LocalEntity001.n1120_invalid_command = -1120;
	}
}